import React from 'react'
import logo from '../../../img/logo.png'

export default () => {
  return (
    <div>
      <div className='logo'>
      <img src={logo} alt={"logo"}/> 
      </div>
    </div>
  )
}

