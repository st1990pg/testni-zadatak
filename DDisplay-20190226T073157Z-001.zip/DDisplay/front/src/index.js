import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App'

import 'index.scss';





ReactDOM.render(<App title="Hello World" title2="Hello World"  />, document.getElementById('root'));